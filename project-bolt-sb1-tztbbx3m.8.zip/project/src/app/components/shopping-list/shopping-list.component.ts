import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShoppingListService, Medicine } from '../../services/shopping-list.service';

@Component({
  selector: 'app-shopping-list',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="shopping-list">
      <h2>List of treatment recommendations</h2>
      <ul class="medicine-list">
        <li *ngFor="let medicine of medicines" class="medicine-item">
          <span>{{ medicine.name }}</span>
          <button class="remove-btn" (click)="removeMedicine(medicine.name)">×</button>
        </li>
      </ul>
      <div *ngIf="medicines.length === 0" class="empty-message">
        No medicines in treatment recommendations
      </div>
    </div>
  `,
  styles: [`
    .shopping-list {
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .medicine-list {
      list-style: none;
      padding: 0;
    }
    .medicine-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px;
      border-bottom: 1px solid #eee;
    }
    .remove-btn {
      background: #ff4444;
      color: white;
      border: none;
      border-radius: 50%;
      width: 24px;
      height: 24px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .empty-message {
      text-align: center;
      color: #666;
      padding: 20px;
    }
  `]
})
export class ShoppingListComponent {
  medicines: Medicine[] = [];

  constructor(private shoppingListService: ShoppingListService) {
    this.shoppingListService.getMedicines().subscribe(
      medicines => this.medicines = medicines
    );
  }

  removeMedicine(name: string) {
    this.shoppingListService.removeMedicine(name);
  }
}