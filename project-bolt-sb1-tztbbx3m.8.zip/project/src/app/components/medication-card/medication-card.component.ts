import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShoppingListService } from '../../services/shopping-list.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-medication-card',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="card" [class.flipped]="isFlipped">
      <div class="add-icon" (click)="toggleMedication($event)" [class.added]="isInList">
        <div class="icon-background"></div>
        <img [src]="isInList ? 
          'https://www.citypng.com/public/uploads/preview/tick-check-correct-true-done-mark-3d-green-icon-png-11664618654ho7xhidr5e.png' : 
          'https://flyclipart.com/thumb2/add-green-cross-health-hospital-medical-symbol-new-plus-icon-163365.png'" 
          [alt]="isInList ? 'Added to list' : 'Add to list'" />
      </div>
      <div class="card-inner" (click)="flip()">
        <div class="card-front">
          <div class="content">
            <h3>{{ medication.name }}</h3>
          </div>
        </div>
        <div class="card-back">
          <p>{{ medication.description }}</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      width: 200px;
      height: 250px;
      perspective: 1000px;
      cursor: pointer;
      margin: 10px;
      position: relative;
    }
    .add-icon {
      position: absolute;
      top: 10px;
      right: 10px;
      z-index: 10;
      width: 40px;
      height: 40px;
      cursor: pointer;
      transition: transform 0.2s ease;
    }
    .icon-background {
      position: absolute;
      top: -5px;
      left: -5px;
      width: calc(100% + 10px);
      height: calc(100% + 10px);
      background: white;
      border-radius: 50%;
      box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    .add-icon:hover {
      transform: scale(1.1);
    }
    .add-icon img {
      position: relative;
      width: 70%;
      height: 70%;
      object-fit: contain;
      z-index: 1;
      margin: 15%;
    }
    .card-inner {
      position: relative;
      width: 100%;
      height: 100%;
      text-align: center;
      transition: transform 0.8s;
      transform-style: preserve-3d;
      transform-origin: center;
    }
    .flipped .card-inner {
      transform: rotateY(180deg);
    }
    .card-front, .card-back {
      position: absolute;
      inset: 0;
      -webkit-backface-visibility: hidden;
      backface-visibility: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .card-front {
      background-image: url('https://plus.unsplash.com/premium_photo-1671721439617-491242a0507f?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8bWVkaWNpbmV8ZW58MHx8MHx8fDA%3D');
      background-size: cover;
      background-position: center;
      color: white;
    }
    .card-front .content {
      background-color: rgba(0, 0, 0, 0.6);
      padding: 10px;
      border-radius: 5px;
      width: 100%;
    }
    .card-front h3 {
      margin: 0;
      font-size: 1.2em;
    }
    .card-back {
      background-color: #f8f9fa;
      transform: rotateY(180deg);
    }
  `]
})
export class MedicationCardComponent implements OnInit, OnDestroy {
  @Input() medication!: { name: string; description: string };
  isFlipped = false;
  isInList = false;
  private subscription: Subscription | null = null;

  constructor(private shoppingListService: ShoppingListService) {}

  ngOnInit() {
    this.subscription = this.shoppingListService.getMedicines().subscribe(medicines => {
      this.isInList = medicines.some(m => m.name === this.medication?.name);
    });
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  flip() {
    this.isFlipped = !this.isFlipped;
  }

  toggleMedication(event: Event) {
    event.stopPropagation();
    if (this.isInList) {
      this.shoppingListService.removeMedicine(this.medication.name);
    } else {
      this.shoppingListService.addMedicine(this.medication);
    }
  }
}