import { Injectable } from '@angular/core';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { Observable, from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  private genAI: GoogleGenerativeAI;
  private model: any;

  constructor() {
    this.genAI = new GoogleGenerativeAI('AIzaSyDEYZbvlMo3oW34j6eBML2ygPOiO40aesw'); 
    this.model = this.genAI.getGenerativeModel({ model: 'gemini-pro' });
  }

  async searchDisease(disease: string): Promise<any> {
    try {
      const prompt = `Provide information about ${disease} in the following JSON format (don't write JSON or any characters before or after the JSON. Don't add additional spaces:
      description: description of the medication,
      symptoms: list of common symptoms,
      medications: List of 6 common medications used for treatment in format: name: name of medication, desription: description of medication`;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Parse the response and validate it's proper JSON
      try {
        const sections = JSON.parse(text);
        
        // Validate the required fields exist
        if (!sections.description || !sections.symptoms || !sections.medications) {
          throw new Error('Invalid response format');
        }

        return {
          description: sections.description,
          symptoms: sections.symptoms,
          medications: sections.medications
        };
      } catch (parseError) {
        throw new Error('Failed to parse API response');
      }
    } catch (error) {
      console.error('Gemini API error:', error);
      throw new Error('Failed to get disease information. Please try again.');
    }
  }
}