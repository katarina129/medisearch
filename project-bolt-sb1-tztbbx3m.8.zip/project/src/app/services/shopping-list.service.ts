import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface Medicine {
  name: string;
  description: string;
}

@Injectable({
  providedIn: 'root'
})
export class ShoppingListService {
  private medicines = new BehaviorSubject<Medicine[]>([]);

  getMedicines() {
    return this.medicines.asObservable();
  }

  addMedicine(medicine: Medicine) {
    const currentMedicines = this.medicines.value;
    if (!currentMedicines.find(m => m.name === medicine.name)) {
      this.medicines.next([...currentMedicines, medicine]);
    }
  }

  removeMedicine(medicineName: string) {
    const currentMedicines = this.medicines.value;
    this.medicines.next(currentMedicines.filter(m => m.name !== medicineName));
  }
}