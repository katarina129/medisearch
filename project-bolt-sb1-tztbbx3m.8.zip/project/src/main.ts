import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MedicationCardComponent } from './app/components/medication-card/medication-card.component';
import { SpinnerComponent } from './app/components/spinner/spinner.component';
import { ShoppingListComponent } from './app/components/shopping-list/shopping-list.component';
import { GeminiService } from './app/services/gemini.service';
import { ShoppingListService } from './app/services/shopping-list.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, MedicationCardComponent, SpinnerComponent, ShoppingListComponent],
  template: `
    <div class="app-container" [ngClass]="{'with-background': !searchResult && !isLoading}">
      <div class="overlay" *ngIf="!searchResult && !isLoading"></div>
      <div class="container">
        <div class="search-container">
          <input 
            type="text" 
            [(ngModel)]="searchQuery" 
            (ngModelChange)="onSearchInput()"
            (keyup.enter)="searchDisease()"
            placeholder="Enter a medical condition..."
            class="search-input"
          >
          <button 
            (click)="searchDisease()" 
            class="search-button"
            [disabled]="isLoading"
          >
            Search
          </button>
        </div>

        <app-spinner *ngIf="isLoading"></app-spinner>

        <div *ngIf="errorMessage" class="error-message">
          {{ errorMessage }}
        </div>

        <app-shopping-list *ngIf="showShoppingList"></app-shopping-list>

        <div class="results-container" *ngIf="searchResult && !isLoading && !showShoppingList">
          <div class="disease-info">
            <h2>{{ searchQuery }}</h2>
            <h3>Description</h3>
            <p>{{ searchResult.description }}</p>
            
            <h3>Common Symptoms</h3>
            <ul class="symptoms-list">
              <li *ngFor="let symptom of searchResult.symptoms">{{ symptom }}</li>
            </ul>
          </div>

          <h3>Medications</h3>
          <div class="medications-grid">
            <app-medication-card
              *ngFor="let medication of searchResult.medications"
              [medication]="medication"
            ></app-medication-card>
          </div>
        </div>

        <div class="bottom-button-container">
          <button 
            *ngIf="searchResult"
            (click)="toggleShoppingList()" 
            class="shopping-list-button"
          >
            {{ showShoppingList ? 'Show Search Results' : 'Show List of treatment recommendations' }}
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .app-container {
      min-height: 100vh;
      padding: 20px 0;
      position: relative;
    }
    .app-container.with-background {
      background-image: url('https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      background-attachment: fixed;
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
    }
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.4);
      pointer-events: none;
    }
    .search-container {
      position: relative;
      z-index: 1;
    }
    .search-input {
      background: rgba(255, 255, 255, 0.95);
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .symptoms-list {
      list-style-type: disc;
      padding-left: 20px;
      margin: 10px 0;
    }
    .symptoms-list li {
      margin: 5px 0;
    }
    .bottom-button-container {
      display: flex;
      justify-content: center;
      margin-top: 30px;
      padding: 20px 0;
    }
    .shopping-list-button {
      padding: 12px 30px;
      font-size: 16px;
      background-color: #28a745;
      color: white;
      border: none;
      border-radius: 25px;
      cursor: pointer;
      transition: background-color 0.3s;
    }
    .shopping-list-button:hover {
      background-color: #218838;
    }
    .error-message {
      background-color: #f8d7da;
      color: #721c24;
      padding: 1rem;
      margin: 1rem 0;
      border-radius: 4px;
      text-align: center;
    }
  `]
})
export class App {
  searchQuery = '';
  searchResult: any = null;
  isLoading = false;
  showShoppingList = false;
  medicineCount = 0;
  errorMessage: string | null = null;

  constructor(
    private geminiService: GeminiService,
    private shoppingListService: ShoppingListService
  ) {
    this.shoppingListService.getMedicines().subscribe(
      medicines => this.medicineCount = medicines.length
    );
  }

  onSearchInput() {
    this.searchResult = null;
    this.errorMessage = null;
  }

  toggleShoppingList() {
    this.showShoppingList = !this.showShoppingList;
  }

  async searchDisease() {
    if (this.searchQuery.trim()) {
      try {
        this.isLoading = true;
        this.errorMessage = null;
        this.searchResult = await this.geminiService.searchDisease(this.searchQuery);
      } catch (error) {
        this.errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
        this.searchResult = null;
      } finally {
        this.isLoading = false;
      }
    }
  }
}

bootstrapApplication(App, {
  providers: [GeminiService, ShoppingListService]
});